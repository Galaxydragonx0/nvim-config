return{


    'numToStr/Comment.nvim',
    opts = {
        -- add any options here
    },
    lazy = false,

    config = function()
		local comment = require('Comment')

		comment.setup()

        vim.keymap.set("n", "<C-_>", function() require('Comment.api').toggle.linewise.current() end, { noremap = true, silent = true })
        vim.keymap.set("v", "<C-_>", function() require('Comment.api').toggle.blockwise.current() end, { noremap = true, silent = true })
	end,
}